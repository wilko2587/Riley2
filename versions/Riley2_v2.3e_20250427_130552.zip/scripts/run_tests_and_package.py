import sys
import os
import unittest
import subprocess
import datetime
import time

# Setup paths
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, root_dir)

riley2_inner_path = os.path.join(root_dir, 'Riley2')
sys.path.insert(0, riley2_inner_path)

logs_dir = os.path.join(root_dir, 'logs')
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
run_log_path = os.path.join(logs_dir, f'test_run_{timestamp}.log')
common_log_path = os.path.join(logs_dir, 'riley2_test.log')

class Tee(object):
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            s.write(data)
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()

sys.stdout = Tee(sys.stdout, open(run_log_path, 'w', encoding='utf-8'), open(common_log_path, 'a', encoding='utf-8'))
sys.stderr = sys.stdout

if __name__ == "__main__":
    start_time = time.time()

    try:
        print("\n🚀 Running all tests...\n")

        loader = unittest.TestLoader()
        tests_path = os.path.join(root_dir, 'Riley2', 'tests')
        suite = loader.discover(start_dir=tests_path)

        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)

        end_time = time.time()
        duration = end_time - start_time

        total_tests = result.testsRun
        total_errors = len(result.errors)
        total_failures = len(result.failures)
        total_passed = total_tests - (total_errors + total_failures)

        print("\n📊 Test Summary:")
        print(f"  ✅ Tests passed: {total_passed}")
        print(f"  ❌ Tests failed: {total_errors + total_failures}")
        print(f"  ⏱️ Duration: {duration:.2f} seconds")

        if result.wasSuccessful():
            print(f"📝 Full test run log saved to {run_log_path}")
            print("\n✅ Tests passed! Running packaging...")
            time.sleep(1)
            subprocess.run(["python", "scripts/package_current_version.py"], check=True)
        else:
            print("\n❌ Tests failed. Skipping packaging.")

    finally:
        sys.stdout.flush()
        sys.stderr.flush()
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
