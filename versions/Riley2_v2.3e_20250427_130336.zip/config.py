
# Riley2 Project Configuration

VERSION = "2.3e"
