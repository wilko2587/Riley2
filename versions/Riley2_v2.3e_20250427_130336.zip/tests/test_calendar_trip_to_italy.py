import inspect
from core.llm_backend import summarize_text
from test_logger import setup_test_logger

test_logger = setup_test_logger()

def test_calendar_trip_to_italy():
    current_function = inspect.currentframe().f_code.co_name
    test_logger.info(f"\033[93m💠 === Starting Test: {current_function} ===\033[0m")
    test_logger.info('Starting test_calendar_trip_to_italy')

    dummy_calendar_data = [
        {"title": "Italy Holiday", "date": "2025-05-15"}
    ]
    today_date = "2025-04-13"
    user_question = f"Today is {today_date}. When is my trip to Italy?"

    dummy_text = f"User asks: {user_question}. Calendar events: {dummy_calendar_data}."

    response = summarize_text(dummy_text)

    assert isinstance(response, str) and ("may" in response.lower() or "15" in response), "Response should mention May 15th."

    test_logger.info(f"\033[92m✅ === Finished Test: {current_function} ===\033[0m")
    test_logger.info('')
